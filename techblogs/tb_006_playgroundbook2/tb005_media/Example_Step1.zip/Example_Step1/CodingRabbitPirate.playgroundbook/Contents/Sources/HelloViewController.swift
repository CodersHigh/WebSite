 import UIKit
 import PlaygroundSupport
 
 public class HelloViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
 }

 
