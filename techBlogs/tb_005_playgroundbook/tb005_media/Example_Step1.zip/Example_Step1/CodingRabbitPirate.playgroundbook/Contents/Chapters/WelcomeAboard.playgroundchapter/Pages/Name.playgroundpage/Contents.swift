//#-hidden-code
//  Contents.swift
//
//  Copyright (c) 2017 CodersHigh. All Rights Reserved.
//

import PlaygroundSupport
import Foundation
import UIKit

//#-end-hidden-code

/*:
 # Welcome to CodersHigh Cruse
 
 It's captain coding rabbit
 
 This is the very first stage of your aboard
 
 Follow the instruction
 
 Hope you have a good chance to improve your coding skill here
 
 
 
 ## Instruction
 Type your name using setName() function
 
 
 setName("CodingRabbit")
 */







