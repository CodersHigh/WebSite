//
//  PassPort.swift
//  
//
//  Created by LingoStar on 17/03/2018.
//

import Foundation

public class PassPort {
    
    public static let shared = PassPort()
    public var name:String?
}
