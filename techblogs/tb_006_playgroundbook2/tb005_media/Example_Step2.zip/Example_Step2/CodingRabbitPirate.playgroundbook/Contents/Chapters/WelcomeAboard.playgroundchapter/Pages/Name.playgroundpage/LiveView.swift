
import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
let helloViewController: HelloViewController = HelloViewController()
page.liveView = helloViewController
