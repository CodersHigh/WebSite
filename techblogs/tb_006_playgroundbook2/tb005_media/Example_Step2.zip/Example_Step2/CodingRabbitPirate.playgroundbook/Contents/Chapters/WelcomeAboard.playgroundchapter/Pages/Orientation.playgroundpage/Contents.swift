//#-hidden-code
//  Contents.swift
//
//  Copyright (c) 2017 CodersHigh. All Rights Reserved.
//

import PlaygroundSupport
import Foundation
import UIKit


let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
//#-end-hidden-code

/*:
 # Newton's Cradle and UIKit Dynamics
 
 This playground uses UIKit Dynamics to create a Newton's Cradle. Commonly seen on desks around the world, Newton's Cradle is a device that illustrates conservation of momentum and energy.
 
 Let's create an instance of our UIKit Dynamics based Newton's Cradle. Try adding more colors to the array to increase the number of balls in the device.
 */



//#-code-completion(everything, hide)

/*#-editable-code*/

/*#-end-editable-code*/

//#-hidden-code

//#-end-hidden-code
